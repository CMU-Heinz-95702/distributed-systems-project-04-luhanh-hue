/**
 * Author: Luhan Huang
 * AndrewID: luhanh
 * Course: 95-702 Distributed Systems
 * Project 4
 *
 * This file is part of my submission for Project .
 */
package ds.edu.project4cryptoclient;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.StrictMode;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    // 🔥 Localhost for Android emulator (10.0.2.2 = host machine)
    private static final String BASE_URL =
            "https://improved-meme-5gpj6g5v4gvrhv9jp-8080.app.github.dev/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Allow network requests on main thread (for this assignment)
        StrictMode.setThreadPolicy(
                new StrictMode.ThreadPolicy.Builder().permitAll().build()
        );

        // UI references
        EditText editCoin = findViewById(R.id.editCoin);
        Button buttonQuote = findViewById(R.id.buttonQuote);

        TextView titleResult = findViewById(R.id.textResultTitle);
        TextView textPrice = findViewById(R.id.textPrice);
        TextView textChange = findViewById(R.id.textChange);
        TextView textVolatility = findViewById(R.id.textVolatility);

        buttonQuote.setOnClickListener(v -> {

            String coin = editCoin.getText().toString().trim();
            if (coin.isEmpty()) {
                editCoin.setError("Enter a coin name!");
                return;
            }

            // Build URL for your servlet
            String url = BASE_URL + "/api/quote?coin=" + coin + "&vs=usd";

            try {
                String json = fetch(url);
                JSONObject obj = new JSONObject(json);

                // If server returned an error JSON
                if (obj.has("error")) {
                    titleResult.setText("Error");
                    titleResult.setVisibility(TextView.VISIBLE);
                    textPrice.setText(obj.getString("error"));
                    textChange.setText("");
                    textVolatility.setText("");
                    return;
                }

                // Parse valid JSON
                double price = obj.getDouble("price");
                double change = obj.getDouble("change24h_pct");
                String volatility = obj.getString("volatility");

                // Display
                titleResult.setText("Result");
                titleResult.setVisibility(TextView.VISIBLE);

                textPrice.setText("Price: " + price);
                textChange.setText("24h Change: " +
                        String.format("%.2f", change) + "%");
                textVolatility.setText("Volatility: " + volatility);

            } catch (Exception e) {
                titleResult.setText("Network Error");
                titleResult.setVisibility(TextView.VISIBLE);

                textPrice.setText(e.toString());
                textChange.setText("");
                textVolatility.setText("");
            }
        });
    }

    // Simple GET request
    private String fetch(String urlStr) throws IOException {
        URL url = new URL(urlStr);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod("GET");
        c.setRequestProperty("Accept", "application/json");
        c.setConnectTimeout(8000);

        BufferedReader br = new BufferedReader(
                new InputStreamReader(c.getInputStream())
        );

        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) {
            sb.append(line);
        }
        br.close();

        return sb.toString();
    }
}
